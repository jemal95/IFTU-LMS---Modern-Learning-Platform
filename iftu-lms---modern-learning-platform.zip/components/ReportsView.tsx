
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, 
  Download, 
  ArrowUpRight, 
  ArrowDownRight, 
  Loader2, 
  Activity, 
  Server, 
  Clock,
  BookOpen,
  GraduationCap,
  FileSpreadsheet,
  Printer,
  PieChart as PieIcon,
  BarChart3,
  Calendar
} from 'lucide-react';
import { 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area,
  Pie,
  Cell,
  PieChart as RePieChart,
  BarChart,
  Bar
} from 'recharts';
import { AuthUser } from '../types';
import { db } from '../utils/persistence';
import { Signature } from './Signature';

interface ReportsViewProps {
  user: AuthUser;
}

// Mock historical data for the Area Chart (hard to derive from simple seed data without dates)
const ENROLLMENT_TRENDS = [
  { month: 'Sep', students: 3800 },
  { month: 'Oct', students: 4200 },
  { month: 'Nov', students: 4500 },
  { month: 'Dec', students: 4450 },
  { month: 'Jan', students: 4800 },
  { month: 'Feb', students: 5100 },
];

export const ReportsView: React.FC<ReportsViewProps> = ({ user }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [stats, setStats] = useState(db.getSystemStats());
  const [activeTab, setActiveTab] = useState<'Students' | 'Teachers' | 'Subjects'>('Students');
  const [isMounted, setIsMounted] = useState(false);

  // Load Data
  const allUsers = useMemo(() => db.getUsers(), []);
  const allCourses = useMemo(() => db.getCourses(), []);
  
  const teachers = useMemo(() => allUsers.filter(u => u.role === 'Teacher'), [allUsers]);
  const students = useMemo(() => allUsers.filter(u => u.role === 'Student'), [allUsers]);

  // Real-time Category Calculation
  const categoryData = useMemo(() => {
    const counts: Record<string, number> = {};
    allCourses.forEach(c => {
      counts[c.category] = (counts[c.category] || 0) + 1;
    });
    const total = allCourses.length || 1;
    const colors = ['#0090C1', '#10b981', '#f59e0b', '#6366f1', '#ec4899'];
    return Object.entries(counts).map(([name, val], idx) => ({
      name,
      value: val,
      percentage: Math.round((val / total) * 100),
      color: colors[idx % colors.length]
    }));
  }, [allCourses]);

  useEffect(() => {
    const timer = setTimeout(() => setIsMounted(true), 150);
    const interval = setInterval(() => setStats(db.getSystemStats()), 5000);
    return () => { clearTimeout(timer); clearInterval(interval); };
  }, []);

  const exportToCSV = (data: any[], fileName: string) => {
    if (data.length === 0) return;
    const headers = Object.keys(data[0]);
    const csvRows = [
      headers.join(','),
      ...data.map(row => headers.map(header => {
        const val = row[header];
        return typeof val === 'object' ? `"${JSON.stringify(val).replace(/"/g, '""')}"` : `"${val}"`;
      }).join(','))
    ];
    const csvContent = '\uFEFF' + csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${fileName}_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const handleDownloadPDF = async () => {
    setIsGenerating(true);
    // Target the hidden printable section
    const element = document.getElementById('printable-report');
    
    if (element && (window as any).html2pdf) {
      const opt = {
        margin: [0.1, 0.1], // Tight margins for a dashboard feel
        filename: `IFTU_Institutional_Report_${new Date().toISOString().split('T')[0]}.pdf`,
        image: { type: 'jpeg', quality: 1.0 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'in', format: 'a4', orientation: 'landscape' }
      };

      try {
        await (window as any).html2pdf().set(opt).from(element).save();
      } catch (error) {
        console.error(error);
        alert("PDF Generation failed.");
      }
    }
    setIsGenerating(false);
  };

  return (
    <div className="p-8 space-y-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-800 tracking-tight">Executive Intelligence</h2>
          <p className="text-sm text-slate-500 mt-1 font-medium">Real-time institutional analytics & exports.</p>
        </div>
        <div className="flex gap-4">
           <button 
             onClick={handleDownloadPDF}
             disabled={isGenerating}
             className="flex items-center gap-2 px-8 py-4 bg-[#0090C1] text-white rounded-[2rem] font-bold shadow-2xl shadow-sky-500/20 hover:bg-[#007ba6] transition-all disabled:opacity-75 disabled:cursor-wait active:scale-95"
           >
             {isGenerating ? <Loader2 size={20} className="animate-spin" /> : <Printer size={20} />}
             {isGenerating ? 'Compiling Report...' : 'Generate Official PDF'}
           </button>
        </div>
      </div>

      {/* Interactive Dashboard View */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        <ReportMetricCard title="Total Students" value={stats.students.toLocaleString()} change="+12.5%" isPositive={true} icon={<GraduationCap size={20} />} color="sky" />
        <ReportMetricCard title="Faculty Count" value={stats.teachers.toLocaleString()} change="+5.2%" isPositive={true} icon={<Users size={20} />} color="emerald" />
        <ReportMetricCard title="Live Subjects" value={stats.subjects.toLocaleString()} change="+2 New" isPositive={true} icon={<BookOpen size={20} />} color="amber" />
        <ReportMetricCard title="Server Uptime" value="99.9%" change="Stable" isPositive={true} icon={<Server size={20} />} color="indigo" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {/* Main Analytics Area */}
        <div className="xl:col-span-2 space-y-8">
          <div className="bg-white rounded-[3rem] border border-slate-100 shadow-sm p-10 space-y-10 relative overflow-hidden">
            <div className="flex items-center justify-between relative z-10">
              <div>
                <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight flex items-center gap-2">
                   <Activity size={20} className="text-[#0090C1]" /> Enrollment Velocity
                </h3>
                <p className="text-xs text-slate-400 font-medium">Monthly student admission trends.</p>
              </div>
              <div className="flex gap-2">
                 <span className="w-3 h-3 rounded-full bg-[#0090C1]"></span>
                 <span className="text-[10px] font-bold text-slate-500 uppercase">Active</span>
              </div>
            </div>
            <div className="h-[340px] w-full block relative z-10">
              {isMounted && (
                <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                  <AreaChart data={ENROLLMENT_TRENDS}>
                    <defs><linearGradient id="colorStudentsRep" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#0090C1" stopOpacity={0.2}/><stop offset="95%" stopColor="#0090C1" stopOpacity={0}/></linearGradient></defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8', fontWeight: 700}} dy={15} />
                    <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8', fontWeight: 700}} />
                    <Tooltip contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 20px 40px -10px rgb(0 0 0 / 0.1)', padding: '12px', fontWeight: 'bold'}} />
                    <Area type="monotone" dataKey="students" stroke="#0090C1" strokeWidth={4} fillOpacity={1} fill="url(#colorStudentsRep)" />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Data Table Widget */}
          <div className="bg-white rounded-[3rem] border border-slate-100 shadow-xl overflow-hidden flex flex-col min-h-[500px]">
            <div className="p-8 bg-slate-50/50 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex gap-2 p-1 bg-white rounded-2xl border border-slate-100 shadow-sm">
                {(['Students', 'Teachers', 'Subjects'] as const).map(tab => (
                  <button 
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
                      activeTab === tab ? 'bg-slate-800 text-white shadow-md' : 'text-slate-400 hover:text-slate-600'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
              <button 
                onClick={() => exportToCSV(activeTab === 'Students' ? students : activeTab === 'Teachers' ? teachers : allCourses, `IFTU_${activeTab}`)}
                className="flex items-center gap-2 px-6 py-2.5 bg-emerald-50 text-emerald-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-100 transition-all border border-emerald-100"
              >
                <FileSpreadsheet size={16} /> Export CSV
              </button>
            </div>

            <div className="overflow-x-auto flex-1">
              <table className="w-full text-left">
                <thead className="bg-white sticky top-0 z-10 text-slate-400 text-[9px] uppercase font-black tracking-widest border-b border-slate-100">
                  <tr>
                    {activeTab === 'Subjects' ? (
                      <>
                        <th className="px-8 py-4">Title</th>
                        <th className="px-8 py-4">Category</th>
                        <th className="px-8 py-4">Instructor</th>
                        <th className="px-8 py-4 text-center">Enrollment</th>
                      </>
                    ) : (
                      <>
                        <th className="px-8 py-4">Full Name</th>
                        <th className="px-8 py-4">ID / Email</th>
                        <th className="px-8 py-4">Department</th>
                        <th className="px-8 py-4 text-center">Status</th>
                      </>
                    )}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {activeTab === 'Subjects' ? (
                    allCourses.map(course => (
                      <tr key={course.id} className="text-xs font-medium hover:bg-slate-50/30 transition-colors">
                        <td className="px-8 py-4 font-bold text-slate-800">{course.title}</td>
                        <td className="px-8 py-4 text-slate-500"><span className="px-2 py-1 bg-slate-100 rounded-md text-[9px] font-bold uppercase">{course.category}</span></td>
                        <td className="px-8 py-4 text-slate-500">{course.instructor}</td>
                        <td className="px-8 py-4 text-slate-500 font-bold text-center">{course.students}</td>
                      </tr>
                    ))
                  ) : (
                    (activeTab === 'Students' ? students : teachers).map(p => (
                      <tr key={p.id} className="text-xs font-medium hover:bg-slate-50/30 transition-colors">
                        <td className="px-8 py-4 font-bold text-slate-800 flex items-center gap-3">
                           <img src={p.avatar} className="w-6 h-6 rounded-lg object-cover" alt="" />
                           {p.name}
                        </td>
                        <td className="px-8 py-4 text-slate-500">{p.email}</td>
                        <td className="px-8 py-4 text-slate-500">{p.department}</td>
                        <td className="px-8 py-4 text-center">
                          <span className={`px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-wide border ${
                            p.status === 'Active' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-slate-50 text-slate-400 border-slate-100'
                          }`}>
                            {p.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-8">
          <div className="bg-white rounded-[3rem] border border-slate-100 shadow-sm p-10 flex flex-col items-center justify-between space-y-8 text-center">
             <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight flex items-center gap-2">
                <PieIcon size={18} className="text-indigo-500" /> Subject Distribution
             </h3>
             <div className="h-[240px] w-full block relative">
                {isMounted && (
                  <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
                    <RePieChart>
                      <Pie data={categoryData} innerRadius={65} outerRadius={85} paddingAngle={8} dataKey="value" stroke="none">
                        {categoryData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                      </Pie>
                      <Tooltip contentStyle={{borderRadius: '12px', fontSize: '10px', fontWeight: 'bold', border: 'none', boxShadow: '0 10px 20px rgba(0,0,0,0.1)'}} />
                    </RePieChart>
                  </ResponsiveContainer>
                )}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                   <h4 className="text-3xl font-black text-slate-800">{allCourses.length}</h4>
                   <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Total Subjects</p>
                </div>
             </div>
             <div className="w-full space-y-3">
                {categoryData.map(c => (
                  <div key={c.name} className="flex items-center justify-between">
                     <div className="flex items-center gap-2"><div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c.color }} /><span className="text-[10px] font-bold text-slate-600">{c.name}</span></div>
                     <span className="text-[10px] font-black text-slate-800">{c.percentage}%</span>
                  </div>
                ))}
             </div>
          </div>

          <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl">
             <div className="absolute top-0 right-0 p-8 opacity-10"><Server size={100} /></div>
             <div className="relative z-10 space-y-6">
                <h4 className="text-xs font-black text-sky-400 uppercase tracking-widest flex items-center gap-2">
                   <Activity size={14} /> System Health
                </h4>
                <div className="space-y-4">
                  <div className="flex justify-between items-center text-xs">
                    <span className="opacity-50 font-medium">Storage Usage</span>
                    <span className="font-bold">{stats.storageUsage}</span>
                  </div>
                  <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-sky-500" style={{ width: '12%' }} />
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="opacity-50 font-medium">Database State</span>
                    <span className="font-bold text-emerald-400 flex items-center gap-1"><span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"/> VERIFIED</span>
                  </div>
                </div>
                <div className="pt-4 flex items-center gap-2 text-[9px] font-black opacity-30 uppercase tracking-[0.2em] border-t border-white/10 mt-2">
                   <Clock size={12} /> Last Sync: {stats.lastSync}
                </div>
             </div>
          </div>
        </div>
      </div>

      {/* =====================================================================================
          HIDDEN PRINTABLE REPORT TEMPLATE
          This section is hidden from the UI but used by html2pdf to generate the document.
      ===================================================================================== */}
      <div className="hidden">
        <div id="printable-report" className="bg-white p-12 text-slate-900 font-sans relative" style={{ width: '1123px', minHeight: '794px' }}>
           
           {/* Report Header */}
           <div className="flex justify-between items-end border-b-4 border-slate-900 pb-6 mb-10">
              <div className="flex gap-4 items-center">
                 <div className="w-16 h-16 bg-[#0090C1] flex items-center justify-center text-white rounded-xl">
                    <BarChart3 size={32} />
                 </div>
                 <div>
                    <h1 className="text-3xl font-black uppercase tracking-tight text-slate-900">IFTU LMS</h1>
                    <p className="text-sm font-bold text-slate-500 uppercase tracking-[0.3em]">Institutional Report</p>
                 </div>
              </div>
              <div className="text-right">
                 <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Generated On</p>
                 <p className="text-lg font-black text-slate-900">{new Date().toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
              </div>
           </div>

           {/* Executive Summary Grid */}
           <div className="mb-10">
              <h2 className="text-sm font-black text-[#0090C1] uppercase tracking-widest mb-4 border-b border-slate-200 pb-2">1. Executive Summary</h2>
              <div className="grid grid-cols-4 gap-4">
                 <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Students</p>
                    <p className="text-3xl font-black text-slate-800 mt-1">{stats.students}</p>
                 </div>
                 <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Teachers</p>
                    <p className="text-3xl font-black text-slate-800 mt-1">{stats.teachers}</p>
                 </div>
                 <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Courses</p>
                    <p className="text-3xl font-black text-slate-800 mt-1">{stats.subjects}</p>
                 </div>
                 <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Campuses</p>
                    <p className="text-3xl font-black text-slate-800 mt-1">{stats.campuses}</p>
                 </div>
              </div>
           </div>

           {/* Department Analysis */}
           <div className="mb-10 flex gap-8">
              <div className="flex-1">
                 <h2 className="text-sm font-black text-[#0090C1] uppercase tracking-widest mb-4 border-b border-slate-200 pb-2">2. Department Distribution</h2>
                 <table className="w-full text-left text-xs">
                    <thead>
                       <tr className="bg-slate-100 uppercase font-black text-slate-500">
                          <th className="p-2 pl-4">Category</th>
                          <th className="p-2 text-right">Count</th>
                          <th className="p-2 text-right pr-4">% Share</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                       {categoryData.map(c => (
                          <tr key={c.name}>
                             <td className="p-2 pl-4 font-bold text-slate-700">{c.name}</td>
                             <td className="p-2 text-right text-slate-600">{c.value}</td>
                             <td className="p-2 text-right pr-4 text-slate-600">{c.percentage}%</td>
                          </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
              <div className="flex-1">
                 <h2 className="text-sm font-black text-[#0090C1] uppercase tracking-widest mb-4 border-b border-slate-200 pb-2">3. System Status</h2>
                 <div className="space-y-3 bg-slate-50 p-6 rounded-xl border border-slate-200">
                    <div className="flex justify-between text-xs font-bold text-slate-600 border-b border-slate-200 pb-2">
                       <span>Storage Usage</span>
                       <span>{stats.storageUsage}</span>
                    </div>
                    <div className="flex justify-between text-xs font-bold text-slate-600 border-b border-slate-200 pb-2">
                       <span>Database Version</span>
                       <span>v1.5 (Stable)</span>
                    </div>
                    <div className="flex justify-between text-xs font-bold text-slate-600 pb-2">
                       <span>Sync Status</span>
                       <span className="text-emerald-600 uppercase">Synchronized</span>
                    </div>
                 </div>
              </div>
           </div>

           {/* Full Staff List (Example of Detailed Data) */}
           <div className="mb-10">
              <h2 className="text-sm font-black text-[#0090C1] uppercase tracking-widest mb-4 border-b border-slate-200 pb-2">4. Faculty Directory (Top 10)</h2>
              <table className="w-full text-left text-xs border border-slate-200">
                 <thead className="bg-slate-900 text-white uppercase font-bold">
                    <tr>
                       <th className="p-2 pl-4">Name</th>
                       <th className="p-2">Role</th>
                       <th className="p-2">Department</th>
                       <th className="p-2">Status</th>
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-200">
                    {teachers.slice(0, 10).map(t => (
                       <tr key={t.id} className="even:bg-slate-50">
                          <td className="p-2 pl-4 font-bold text-slate-800">{t.name}</td>
                          <td className="p-2 text-slate-600">{t.role}</td>
                          <td className="p-2 text-slate-600">{t.department}</td>
                          <td className="p-2 text-slate-600">{t.status}</td>
                       </tr>
                    ))}
                 </tbody>
              </table>
              <p className="text-[10px] text-slate-400 italic mt-2 text-center">* Full list available in CSV export.</p>
           </div>

           {/* Footer */}
           <div className="absolute bottom-12 left-12 right-12 flex justify-between items-end border-t-2 border-slate-200 pt-4">
              <div>
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">IFTU LMS Internal Document</p>
                 <p className="text-[10px] text-slate-300">Confidential - For Administrative Use Only</p>
              </div>
              <div className="text-right">
                 <Signature className="w-24 h-12 text-slate-800 mb-1 ml-auto" />
                 <p className="text-[10px] font-black text-slate-800 uppercase">Approved By System Admin</p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

const ReportMetricCard: React.FC<{ title: string; value: string; change: string; isPositive: boolean; icon: React.ReactNode; color: string; }> = ({ title, value, change, isPositive, icon, color }) => {
  const colorMap: Record<string, string> = {
    sky: 'bg-sky-50 text-sky-600', emerald: 'bg-emerald-50 text-emerald-600', amber: 'bg-amber-50 text-amber-600', indigo: 'bg-indigo-50 text-indigo-600',
  };
  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl transition-all group hover:-translate-y-1">
      <div className="flex items-center justify-between mb-8">
        <div className={`p-4 rounded-2xl transition-all duration-500 group-hover:rotate-12 ${colorMap[color]}`}>{icon}</div>
        <div className={`flex items-center gap-1 text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full ${isPositive ? 'bg-emerald-50 text-emerald-500' : 'bg-rose-50 text-rose-500'}`}>
          {isPositive ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}{change}
        </div>
      </div>
      <div><p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">{title}</p><h4 className="text-3xl font-black text-slate-800 mt-2 tracking-tight group-hover:text-[#0090C1] transition-colors">{value}</h4></div>
    </div>
  );
};
