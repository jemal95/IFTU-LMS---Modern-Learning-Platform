
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  Save, 
  Filter, 
  ArrowUpDown, 
  BookOpen, 
  Calculator, 
  GraduationCap, 
  TrendingUp,
  MoreHorizontal
} from 'lucide-react';
import { AuthUser, User, StudentAcademicRecord, SubjectGrade } from '../types';
import { db } from '../utils/persistence';

interface GradebookViewProps {
  user: AuthUser;
}

const SUBJECTS = [
  'MATHEMATICS', 'PHYSICS', 'CHEMISTRY', 'BIOLOGY', 'ENGLISH', 
  'AFAAN OROMOO', 'AMHARIC', 'CIVICS', 'IT', 'HPE',
  'ECONOMICS', 'GENERAL BUSINESS', 'TECHNICAL DRAWING'
];

export const GradebookView: React.FC<GradebookViewProps> = ({ user }) => {
  const [search, setSearch] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('MATHEMATICS');
  const [students, setStudents] = useState<User[]>([]);
  const [grades, setGrades] = useState<Record<string, { sem1: number, sem2: number }>>({});
  const [sortConfig, setSortConfig] = useState<{ key: 'name' | 'score', direction: 'asc' | 'desc' }>({ key: 'name', direction: 'asc' });
  const [showSaveToast, setShowSaveToast] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Load Data
  useEffect(() => {
    const allUsers = db.getUsers();
    // Filter only active students
    const studentUsers = allUsers.filter(u => u.role === 'Student' && u.status === 'Active');
    setStudents(studentUsers);

    // Load existing grades for the selected subject
    const gradesMap: Record<string, { sem1: number, sem2: number }> = {};
    const records = db.getAcademicRecords();
    
    studentUsers.forEach(s => {
      const record = records.find(r => r.studentId === s.id);
      // Access current year subjects
      const subjectRecord = record?.subjects?.[selectedSubject] as SubjectGrade | undefined;
      
      if (subjectRecord) {
        gradesMap[s.id] = {
          sem1: subjectRecord.sem1,
          sem2: subjectRecord.sem2
        };
      } else {
        gradesMap[s.id] = { sem1: 0, sem2: 0 };
      }
    });
    setGrades(gradesMap);
  }, [selectedSubject]);

  const handleGradeChange = (studentId: string, type: 'sem1' | 'sem2', value: string) => {
    // Allow empty string for backspacing
    if (value === '') {
        setGrades(prev => ({
            ...prev,
            [studentId]: { ...prev[studentId], [type]: 0 } // Store as 0 internally but maybe handle UI display differently if needed
        }));
        return;
    }
    const numValue = Math.min(100, Math.max(0, parseInt(value) || 0));
    setGrades(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [type]: numValue
      }
    }));
  };

  const handleSaveAll = () => {
    setIsSaving(true);
    setTimeout(() => {
        Object.entries(grades).forEach(([studentId, scores]) => {
        const s = scores as { sem1: number; sem2: number };
        db.saveStudentGrade(studentId, selectedSubject, 'sem1', s.sem1);
        db.saveStudentGrade(studentId, selectedSubject, 'sem2', s.sem2);
        });
        setIsSaving(false);
        setShowSaveToast(true);
        setTimeout(() => setShowSaveToast(false), 3000);
    }, 800);
  };

  const handleSort = (key: 'name' | 'score') => {
    setSortConfig(current => ({
      key,
      direction: current.key === key && current.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const processedStudents = useMemo(() => {
    let filtered = students.filter(s => 
      s.name.toLowerCase().includes(search.toLowerCase()) || 
      s.id.toLowerCase().includes(search.toLowerCase())
    );

    return filtered.sort((a, b) => {
      if (sortConfig.key === 'name') {
        return sortConfig.direction === 'asc' 
          ? a.name.localeCompare(b.name) 
          : b.name.localeCompare(a.name);
      } else {
        const scoreA = ((grades[a.id]?.sem1 || 0) + (grades[a.id]?.sem2 || 0)) / 2;
        const scoreB = ((grades[b.id]?.sem1 || 0) + (grades[b.id]?.sem2 || 0)) / 2;
        return sortConfig.direction === 'asc' ? scoreA - scoreB : scoreB - scoreA;
      }
    });
  }, [students, search, grades, sortConfig]);

  const getGradeColor = (score: number) => {
    if (score >= 90) return 'text-emerald-600 bg-emerald-50 border-emerald-100';
    if (score >= 80) return 'text-sky-600 bg-sky-50 border-sky-100';
    if (score >= 70) return 'text-indigo-600 bg-indigo-50 border-indigo-100';
    if (score >= 50) return 'text-amber-600 bg-amber-50 border-amber-100';
    return 'text-rose-600 bg-rose-50 border-rose-100';
  };

  const getLetterGrade = (score: number) => {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 50) return 'D';
    return 'F';
  };

  // Stats Calculation
  const stats = useMemo(() => {
    const scores = Object.values(grades).map((g: { sem1: number; sem2: number }) => (g.sem1 + g.sem2) / 2);
    const total = scores.length;
    if (total === 0) return { avg: 0, passRate: 0, highest: 0 };
    
    const avg = Math.round(scores.reduce((a, b) => a + b, 0) / total);
    const passCount = scores.filter(s => s >= 50).length;
    const highest = Math.max(...scores);
    
    return {
        avg,
        passRate: Math.round((passCount / total) * 100),
        highest
    };
  }, [grades]);

  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-500">
      {/* Toast */}
      {showSaveToast && (
        <div className="fixed top-24 right-8 z-[70] animate-in slide-in-from-right-4 duration-300">
          <div className="bg-emerald-500 text-white px-6 py-4 rounded-2xl shadow-xl flex items-center gap-3">
            <CheckCircle2 size={24} />
            <div>
              <p className="font-bold text-sm">Changes Saved</p>
              <p className="text-xs opacity-90">Transcript data updated successfully.</p>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-3">
             <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
                <BookOpen size={28} />
             </div>
             <div>
                <h2 className="text-3xl font-black text-slate-800 tracking-tight">Digital Gradebook</h2>
                <p className="text-sm text-slate-500 font-bold mt-1 uppercase tracking-widest">Academic Records & Scoring</p>
             </div>
          </div>
        </div>
        <div className="flex items-center gap-4">
           <div className="relative group">
              <select 
                value={selectedSubject} 
                onChange={(e) => setSelectedSubject(e.target.value)}
                className="appearance-none bg-white border border-slate-200 text-slate-700 font-bold py-4 pl-6 pr-12 rounded-2xl shadow-sm focus:outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all cursor-pointer text-sm"
              >
                {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <ArrowUpDown className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
           </div>
           <button 
             onClick={handleSaveAll}
             disabled={isSaving}
             className="flex items-center gap-2 px-8 py-4 bg-[#0090C1] text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-sky-500/20 hover:bg-[#007ba6] transition-all active:scale-95 disabled:opacity-75"
           >
             {isSaving ? <TrendingUp size={18} className="animate-spin" /> : <Save size={18} />}
             {isSaving ? 'Committing...' : 'Save Grades'}
           </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-5">
            <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center">
               <Calculator size={24} />
            </div>
            <div>
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Class Average</p>
               <h4 className="text-3xl font-black text-slate-800">{stats.avg}%</h4>
            </div>
         </div>
         <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-5">
            <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
               <CheckCircle2 size={24} />
            </div>
            <div>
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Pass Rate</p>
               <h4 className="text-3xl font-black text-slate-800">{stats.passRate}%</h4>
            </div>
         </div>
         <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-5">
            <div className="w-14 h-14 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center">
               <GraduationCap size={24} />
            </div>
            <div>
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Highest Score</p>
               <h4 className="text-3xl font-black text-slate-800">{stats.highest}</h4>
            </div>
         </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-[3rem] border border-slate-100 shadow-xl overflow-hidden min-h-[500px] flex flex-col">
         {/* Toolbar */}
         <div className="p-8 border-b border-slate-100 flex flex-col md:flex-row justify-between items-center gap-6 bg-slate-50/50">
            <div className="relative w-full md:w-96 group">
               <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-[#0090C1] transition-colors" size={20} />
               <input 
                 type="text" 
                 placeholder="Find student..." 
                 className="w-full pl-14 pr-6 py-4 bg-white border border-slate-200 rounded-2xl outline-none font-bold text-slate-600 focus:border-[#0090C1] transition-all"
                 value={search}
                 onChange={(e) => setSearch(e.target.value)}
               />
            </div>
            <div className="flex gap-2">
               <button onClick={() => handleSort('name')} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${sortConfig.key === 'name' ? 'bg-slate-200 text-slate-800' : 'text-slate-400 hover:bg-slate-100'}`}>Sort Name</button>
               <button onClick={() => handleSort('score')} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${sortConfig.key === 'score' ? 'bg-slate-200 text-slate-800' : 'text-slate-400 hover:bg-slate-100'}`}>Sort Score</button>
            </div>
         </div>

         {/* Table Content */}
         <div className="overflow-x-auto flex-1">
            <table className="w-full text-left border-collapse">
               <thead className="bg-white text-slate-400 text-[10px] uppercase font-black tracking-widest border-b border-slate-100 sticky top-0 z-10">
                  <tr>
                     <th className="px-10 py-6 bg-white">Student Identity</th>
                     <th className="px-6 py-6 text-center bg-white w-32">Sem 1 (50%)</th>
                     <th className="px-6 py-6 text-center bg-white w-32">Sem 2 (50%)</th>
                     <th className="px-6 py-6 text-center bg-white w-24">Average</th>
                     <th className="px-6 py-6 text-center bg-white w-24">Grade</th>
                     <th className="px-6 py-6 text-center bg-white w-32">Status</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-50">
                  {processedStudents.map(student => {
                     const s1 = grades[student.id]?.sem1 || 0;
                     const s2 = grades[student.id]?.sem2 || 0;
                     const avg = Math.round((s1 + s2) / 2);
                     const letter = getLetterGrade(avg);
                     const colorClass = getGradeColor(avg);

                     return (
                        <tr key={student.id} className="hover:bg-slate-50/50 transition-colors group">
                           <td className="px-10 py-5">
                              <div className="flex items-center gap-4">
                                 <img src={student.avatar} className="w-10 h-10 rounded-xl object-cover border border-slate-200" alt="" />
                                 <div>
                                    <p className="text-sm font-bold text-slate-800">{student.name}</p>
                                    <p className="text-[10px] font-mono text-slate-400 mt-0.5">{student.id}</p>
                                 </div>
                              </div>
                           </td>
                           <td className="px-6 py-5 text-center">
                              <input 
                                type="number" 
                                min="0" max="100" 
                                className="w-20 py-2 text-center font-bold text-slate-700 bg-slate-100 rounded-lg border border-transparent focus:bg-white focus:border-[#0090C1] outline-none transition-all"
                                value={s1 || ''}
                                onChange={(e) => handleGradeChange(student.id, 'sem1', e.target.value)}
                              />
                           </td>
                           <td className="px-6 py-5 text-center">
                              <input 
                                type="number" 
                                min="0" max="100" 
                                className="w-20 py-2 text-center font-bold text-slate-700 bg-slate-100 rounded-lg border border-transparent focus:bg-white focus:border-[#0090C1] outline-none transition-all"
                                value={s2 || ''}
                                onChange={(e) => handleGradeChange(student.id, 'sem2', e.target.value)}
                              />
                           </td>
                           <td className="px-6 py-5 text-center">
                              <span className="text-sm font-black text-slate-800">{avg}</span>
                           </td>
                           <td className="px-6 py-5 text-center">
                              <span className={`inline-block w-8 h-8 leading-8 text-center rounded-lg text-xs font-black border ${colorClass}`}>
                                 {letter}
                              </span>
                           </td>
                           <td className="px-6 py-5 text-center">
                              {avg >= 50 ? (
                                 <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[9px] font-black uppercase border border-emerald-100">
                                    <CheckCircle2 size={10} /> Pass
                                 </span>
                              ) : (
                                 <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-50 text-rose-600 rounded-full text-[9px] font-black uppercase border border-rose-100">
                                    <AlertCircle size={10} /> Fail
                                 </span>
                              )}
                           </td>
                        </tr>
                     );
                  })}
                  {processedStudents.length === 0 && (
                     <tr>
                        <td colSpan={6} className="px-10 py-20 text-center text-slate-400 font-medium italic">
                           No active students found for this subject.
                        </td>
                     </tr>
                  )}
               </tbody>
            </table>
         </div>
      </div>
    </div>
  );
};
